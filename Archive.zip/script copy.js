function sumone(a, b) {
	var a = 5;
	var b = 5;

	var x = a + b;

	function sumtwo() {
		var x = x * a / b;
	}
		function sumtthree(){
			var x = x + a + b;	
		}
	alert(x);
}